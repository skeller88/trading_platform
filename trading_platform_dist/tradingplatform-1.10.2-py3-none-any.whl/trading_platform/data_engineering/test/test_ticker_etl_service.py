import unittest


class TestTickerEtlService(unittest.TestCase):
    def setUp(self):
        pass

    def test_by_exchange_and_pair(self):
        pass