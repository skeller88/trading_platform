"""
I'm using this module as an enum because I can't figure out how to do that sensibly with classes in Python.
"""

binance = 'Binance'
bitflyer = 'Bitflyer'
bittrex = 'Bittrex'
coinbase = 'Coinbase'
gdax = 'Gdax'
gemini = 'Gemini'
kraken = 'Kraken'
kucoin = 'Kucoin'
poloniex = 'Poloniex'

all_names = [binance, bitflyer, bittrex, coinbase, gdax, gemini, kucoin, kraken, poloniex]