def print_if_debug_enabled(debug, *args):
    if debug:
        print(*args)