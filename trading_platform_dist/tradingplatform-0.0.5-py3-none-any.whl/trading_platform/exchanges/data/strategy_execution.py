class StrategyExecution:
    def __init__(self, strategy_execution_id: str):
        self.strategy_execution_id: str = strategy_execution_id
