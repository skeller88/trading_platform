import os

from tweepy import OAuthHandler, Stream

import sys
sys.path.append(os.getcwd().replace('twitter', ''))

from trading_platform.twitter.stream_listener import StreamListener
from trading_platform.twitter.twitter_properties import TwitterProperties

if __name__ == '__main__':
    l = StreamListener()
    auth = OAuthHandler(TwitterProperties.consumer_key, TwitterProperties.consumer_secret)
    auth.set_access_token(TwitterProperties.access_token, TwitterProperties.access_token_secret)

    stream = Stream(auth, l)
    # stream.filter(follow=['binance'], track=['lists'])
    stream.filter(track=['binance'])