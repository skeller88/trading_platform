class StrategyType:
    arb = 0
    nm = 1