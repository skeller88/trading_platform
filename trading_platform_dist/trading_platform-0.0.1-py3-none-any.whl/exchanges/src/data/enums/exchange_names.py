"""
I'm using this module as an enum because I can't figure out how to do that sensibly with classes in Python.
"""

binance = 'Binance'
bittrex = 'Bittrex'
gdax = 'Gdax'
kraken = 'Kraken'
poloniex = 'Poloniex'

all_names = [binance, bittrex, gdax, kraken, poloniex]