class DataReader:
    pass