from sqlalchemy.ext.declarative import declarative_base

# tables = [
#     # SqlAlchemyArbitrageAttemptDto,
#     # SqlAlchemyArbitrageOpportunityDto,
#     SqlAlchemyBalanceDto,
#     # SqlAlchemyOpenOrderDto,
#     # SqlAlchemyOrderDto,
#     # SqlAlchemyTickerDto
# ]

Base = declarative_base()
