"""
I'm using this module as an enum because I can't figure out how to do that sensibly with classes in Python.
"""

binance = 'Binance'
bittrex = 'Bittrex'
gdax = 'Gdax'
gemini = 'Gemini'
kraken = 'Kraken'
kucoin = 'Kucoin'
poloniex = 'Poloniex'

all_names = [binance, bittrex, gdax, gemini, kucoin, kraken, poloniex]